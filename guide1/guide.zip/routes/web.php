<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/company-add', function () {
    return view('company-add');
});

Route::get('/page-contact', function () {
    return view('page-contact');
});
Route::get('/page-blog', function () {
    return view('page-blog');
});

    Route::get('/company-list', function () {
    return view('company-list');
});
    Route::get('/user-login', function () {
        return view('user-login');
    });

   Route::get('/user-register', function () {
       return view('user-register');
   });

   Route::get('/company-detail', function () {
       return view('company-detail');
   });

  Route::get('/page-post', function () {
      return view('page-post');
  });

  Route::get('/page-faq', function () {
      return view('page-faq');
  });

    Route::get('/job-list', function () {
    return view('job-list-1');
});
