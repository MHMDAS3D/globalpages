<?php $__env->startSection('content'); ?>


    <!-- Site header -->
    <header class="page-header bg-img size-xl overlay-light" style="background-image: url('https://static.pexels.com/photos/428301/pexels-photo-428301.jpeg')">
      <div class="container no-shadow">
        <h1 class="text-center">Office Dress Code Do's and Don'ts</h1>
        <p class="lead text-center"><time datetime="2016-03-28 20:00">March 28, 2016</time></p>
      </div>
    </header>
    <!-- END Site header -->


    <!-- Main container -->
    <main class="container blog-page">

      <div class="row">
        <div class="col-md-8 col-lg-9">

          <article class="post">

            <div class="blog-content">
              <p>Was certainty sing remaining along how dare dad apply discover only. Settled opinion how enjoy so shy joy greater one. No properly day fat surprise and interest nor adapted replying she love. Bore tall nay too into many time expenses . Doubtful for answered yet less indulged margaret her post shutters together. Ladies many wholly around whence.</p>
            
              <h5>What to wear</h5>
              <p>Residence certainly elsewhere something she preferred it cordially law. Age his surprise formerly perceive those few stanhill moderate. Of in power match on truth worse voice would. Large an it sense shall match learn. By expect result silent in formal of. Ask eat questions abilities described elsewhere stuff.</p>

              <blockquote>Kindness to he horrible reserved ye. Effect twenty indeed beyond for not had county. Them to him without greatly can private. Increasing it unpleasant no of contrasted no continue.</blockquote>

              <p>Give lady of they such they sure it. Me <strong>contained</strong> explained my education. Vulgar as hearts by garret meant  at no stuff. Perceived <i>determine departure</i> explained no forfeited he something an. Contrasted dissimilar get joy you instrument out reasonably. Again keeps.</p>

              <br>
              <p><img src="assets/img/blog-3.jpg" alt="..."></p>
              <br>

              <h5>Say Yes to Capris</h5>
              <p>Residence certainly elsewhere something she preferred it cordially law. Age his surprise formerly perceive those few stanhill moderate. Of in power match on truth worse voice would. Large an it sense shall match learn. By expect result silent in formal of. Ask eat questions abilities described elsewhere stuff.</p>
              
            </div>

            <ul class="post-meta">
              <li>
                <strong>Posted in: </strong>
                <a href="#">Candidates</a>
              </li>

              <li>
                <strong>Tags: </strong>
                <a href="#">Work</a>, 
                <a href="#">Dress</a>, 
                <a href="#">Suit</a>, 
                <a href="#">Workspace</a>
              </li>
            </ul>


            
          </article>

        </div>
        
        <div class="col-md-4 col-lg-3">

          <div class="widget">
            <h6 class="widget-title">Search</h6>
            <div class="widget-body">
              <form method="get" target="#">
                <input class="form-control" type="text" name="s" placeholder="Enter your keyword">
              </form>
            </div>
          </div>

          <div class="widget">
            <h6 class="widget-title">Popular</h6>
            <ul class="widget-body media-list">
              <li>
                <div class="thumb"><a href="page-post"><img src="assets/img/blog-1-thumb.jpg" alt="..."></a></div>
                <div class="content">
                  <h5><a href="page-post">How to Design Your Workspace for Productivity</a></h5>
                  <time datetime="2016-04-04 20:00">April 04, 2016</time>
                </div>
              </li>

              <li>
                <div class="thumb"><a href="page-post"><img src="assets/img/blog-2-thumb.jpg" alt="..."></a></div>
                <div class="content">
                  <h5><a href="page-post">Office Dress Code Do's and Don'ts</a></h5>
                  <time datetime="2016-03-28 20:00">March 28, 2016</time>
                </div>
              </li>

              <li>
                <div class="thumb"><a href="page-post"><img src="assets/img/blog-3-thumb.jpg" alt="..."></a></div>
                <div class="content">
                  <h5><a href="page-post">Why People Thrive in Coworking Spaces</a></h5>
                  <time datetime="2016-03-17 20:00">March 17, 2016</time>
                </div>
              </li>
            </ul>
          </div>

          <div class="widget widget_categories">
            <h6 class="widget-title">Categories</h6>
            <ul class="widget-body">
              <li class="cat-item"><a href="#">News</a></li>
              <li class="cat-item"><a href="#">Companies</a></li>
              <li class="cat-item"><a href="#">Market</a></li>
              <li class="cat-item"><a href="#">Candidates</a></li>
              <li class="cat-item"><a href="#">Positions</a></li>
              <li class="cat-item"><a href="#">Stats</a></li>
            </ul>
          </div>

          <div class="widget widget_tag_cloud">
            <h6 class="widget-title">Tags</h6>
            <div class="widget-body">
              <a href="#">blog</a>
              <a href="#">new</a>
              <a href="#">google</a>
              <a href="#">position</a>
              <a href="#">facebook</a>
              <a href="#">hire</a>
              <a href="#">chance</a>
              <a href="#">resume</a>
              <a href="#">tip</a>
            </div>
          </div>

        </div>
      </div>

    </main>
    <!-- END Main container -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>